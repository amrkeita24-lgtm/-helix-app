#!/bin/bash
# HELIX Mobile App - Quick Start Script

echo "🚀 HELIX Mobile App Setup"
echo "=========================="

# Check prerequisites
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install Node.js 22+"
    exit 1
fi

echo "✅ Node.js found"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Check if images exist
if [ ! -d "www/images" ] || [ -z "$(ls -A www/images 2>/dev/null)" ]; then
    echo "⚠️  Warning: No images found in www/images/"
    echo "   Please copy your images from the original website"
fi

# Add Android if not exists
if [ ! -d "android" ]; then
    echo "📱 Adding Android platform..."
    npx cap add android
fi

# Sync
echo "🔄 Syncing web assets..."
npx cap sync

echo ""
echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "1. Copy your images to www/images/"
echo "2. Run: npx cap open android"
echo "3. In Android Studio: Build → Generate Signed APK"
echo ""
echo "For live reload development:"
echo "   npx cap run android -l --external"
