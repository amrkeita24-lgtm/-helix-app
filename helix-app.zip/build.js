const fs = require('fs');
const path = require('path');

// Ensure images directory exists
const imgDir = path.join(__dirname, 'www', 'images');
if (!fs.existsSync(imgDir)) {
  fs.mkdirSync(imgDir, { recursive: true });
  console.log('Created images directory');
}

console.log('Build complete! Run: npx cap sync');
